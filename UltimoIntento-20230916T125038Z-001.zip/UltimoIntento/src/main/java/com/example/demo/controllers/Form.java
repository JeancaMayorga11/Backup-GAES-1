package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;


import com.example.demo.clases.Usuario;
import com.example.demo.clases.interfaces.UsuarioD;



@Controller
public class Form {

	@Autowired
	private UsuarioD repositorio;
	
	@GetMapping("/form")	
	public String form(Usuario usuario) {
		return "form";
	}
	
	
	@PostMapping("/form")
	public String resultado(Usuario usuario, BindingResult result, Model model) {
		if(result.hasErrors()) {
			model.addAttribute("error", "Completa todos los campos");
		}
		
		usuario.reset();
		repositorio.save(usuario);
		model.addAttribute("usuario", usuario);
		return "form";
	}
}
