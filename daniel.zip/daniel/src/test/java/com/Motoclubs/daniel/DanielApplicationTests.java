package com.Motoclubs.daniel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DanielApplicationTests {

	@Test
	void contextLoads() {
	}

}
